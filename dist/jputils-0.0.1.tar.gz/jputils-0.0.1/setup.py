from setuptools import setup

setup(name='jputils',
      version='0.0.1',
      description='util modules by Jade',
      url='https://github.com/indiflex/jputils',
      author='Jade IndiFlex',
      author_email='indiflex.corp@gmail.com',
      license='MIT',
      packages=['jputils'],
      install_requires=['requests'],
      zip_safe=False)
